#!/usr/bin/env python

# -*- coding: utf-8 -*-
#RIASC Tool For Removing Redundancies(RTRR), a tool for erasing variables of type 1, type 2 and type 3.
#Copyright (C) 2017  by RIASC Universidad de Leon(Miguel Carriegos Vieira, Noemi De Castro Garcia, Angel Luis Munoz, Mario Fernandez Rodriguez)
#This file is part of RIASC Tool for Removing Redundancies (RTRR)
#RTRR is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.
#RTRR is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program. If not, see <http://www.gnu.org/licenses/>.


import sys
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import StringIO

def generar_grafo_no_dirigido(adjacency_matrix,mylabels,indice_max_nombres,indice_max_apellidos,estructura):
    adjacency_matrix = np.array(adjacency_matrix)
     #Grafo de colores
    etiquetas = {}
    for elemento in  mylabels:
        etiquetas[elemento] = mylabels[elemento]
    gr = nx.Graph()
    gr.clear()
    gr = nx.Graph()
    
    #flechas
    rows, cols = np.where(adjacency_matrix == 1)
    edges = zip(rows.tolist(), cols.tolist())      
    gr.add_edges_from(edges)
      
    # nodos y colores
    nodos_nombres = []
    nodos_apellidos = []
    for indice in range(0,indice_max_nombres):
        nodos_nombres.append(indice)
    
    for indice in range(indice_max_nombres,indice_max_apellidos):
        nodos_apellidos.append(indice)
    
    gr.add_nodes_from(nodos_nombres)
    gr.add_nodes_from(nodos_apellidos) 
    
    color_map = []
    for node in gr:
        if node in range(0,indice_max_nombres):
            color_map.append('green')
        else:
            color_map.append('yellow')
            
    #generacion del grafo
    if estructura == "":  
        position=nx.spring_layout(gr)    
    else:
        position=estructura
    f = plt.figure(figsize=(50,50))    
    for indice in nx.isolates(gr):
        etiquetas.pop(indice)
        color_map[indice] = 'deleted'
    
    while 'deleted' in color_map: color_map.remove('deleted')
    gr.remove_nodes_from(nx.isolates(gr))
    nx.draw(gr,pos=position,labels=etiquetas,node_color=color_map,font_size=6,font_weight='bold',node_size=500,linewidths=0.1)
    buf=StringIO.StringIO()
    f.savefig(buf,format='svg')
    buf.seek(0)
    grafo_texto = buf.read()
    buf.close()
    return [grafo_texto,position]

def imprimir_variables_redundantes(variables_redundantes,directorio_salida,tipo_redundancia):
    variables_redundantes = sorted(variables_redundantes)
    informacion= "# Removing variales with redundancy of type " + tipo_redundancia + " #"
    print "%s\t%s" %(directorio_salida,informacion)
    print "%s\t" %(directorio_salida)
    informacion = "There have been removed " + str(len(variables_redundantes)) + " redundant variables of type " + tipo_redundancia + ". They are: "
    print "%s\t%s" %(directorio_salida,informacion)
    for elemento in variables_redundantes:
        print "%s\t%s" %(directorio_salida,elemento)
    print "%s\t" %(directorio_salida)

#funcion que calcula el procentaje de redundancia de la matriz de adyacencia original con respecto a la matriz de adyacencia prima
def imprimir_porcentajes_redundancia(matriz_adyacencia,matriz_adyacencia_input,matriz_adyacencia_prima,variables_redundantes,directorio_salida):
    A_original = float(np.count_nonzero(matriz_adyacencia)) #float(count_nonzero(matriz_adyacencia))
    A_prima = float(np.count_nonzero(matriz_adyacencia_prima)) #float(count_nonzero(matriz_adyacencia_prima))
    A_entrada = float(np.count_nonzero(matriz_adyacencia_input))
    porcentaje_redundancia = (A_original - A_prima) / A_original

    #volcamos los datos a un fichero
    informacion = "||Redundancy percentage ||"
    print "%s\t%s" %(directorio_salida,informacion)
    redundancy_percentage_current_type = len(variables_redundantes) / float(A_original)
    informacion = "% of redundancy of this type over the initial number of variables " + str(redundancy_percentage_current_type)
    print "%s\t%s" %(directorio_salida,informacion)

    partial_redundancy_current_type = len(variables_redundantes) / float(A_entrada)
    informacion = "% of partial redundancy -from the input matrix to the output matrix'-: " +str(partial_redundancy_current_type)
    print "%s\t%s" %(directorio_salida,informacion)

    porcentaje_redundancia_acumulativo = (A_original - A_prima) / A_original
    informacion = "% of accumulative redundancy -from the original matrix to the output matrix-: " + str(porcentaje_redundancia_acumulativo)
    print "%s\t%s" %(directorio_salida,informacion)
    print "%s\t" %(directorio_salida)
            
#funcion que genera  algunos datos a modo de comprobacion
def generar_estadisticas_matrices(matriz_asociada,matriz_adyacencia,variables_eliminadas,variables_redundantes,directorio_salida,variables_csv_final):
    informacion = "||Summary of the redundancy removing ||"
    print "%s\t%s" %(directorio_salida,informacion)
    print "%s\t" %(directorio_salida)
    informacion ="Adjacency matrix: Rows - %s x Columns - %s" %(len(matriz_adyacencia),len(matriz_adyacencia[0]))
    print "%s\t%s" %(directorio_salida,informacion)
    #informacion+="Matriz_general_pesos: Filas - " + str(len(matriz_general_pesos)) +  " x  Columnas - " + str(len(matriz_general_pesos[0]))
    #print "%s\t" %(directorio_salida)
    #informacion+="Csv sin redundancia tipo 1: Filas - " +  str(len(matriz_csv_final)) + " x Columnas- " + str(len(matriz_csv_final[0]))
    informacion ="Number of variables removed: " + str(len(variables_eliminadas) + len(variables_redundantes)) + " de las cuales " + str(len(variables_redundantes)) + " son redundantes."
    print "%s\t%s" %(directorio_salida,informacion)
    informacion ="Numer of variables in the final csv: " + str(len(variables_csv_final))
    print "%s\t%s" %(directorio_salida,informacion)
    print "%s\t" %(directorio_salida)

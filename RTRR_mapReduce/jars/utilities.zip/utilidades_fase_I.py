#!/usr/bin/env python

# -*- coding: utf-8 -*-
#RIASC Tool For Removing Redundancies(RTRR), a tool for erasing variables of type 1, type 2 and type 3.
#Copyright (C) 2017  by RIASC Universidad de Leon(Miguel Carriegos Vieira, Noemi De Castro Garcia, Angel Luis Munoz, Mario Fernandez Rodriguez)
#This file is part of RIASC Tool for Removing Redundancies (RTRR)
#RTRR is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.
#RTRR is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program. If not, see <http://www.gnu.org/licenses/>.

#Modulo de funciones comunes

import csv
import sys
import math

#------mapper_reducer generar_listas_variables
#funcion que recupera la lista de variables eliminadas
def obtener_lista_variables_fichero(ruta_fichero_variables,separador):
    lista_variables=[]
    with open(ruta_fichero_variables, 'r') as archivo_csv:
        lector_archivo = csv.reader(archivo_csv,delimiter=separador)
        for variable in lector_archivo:
            if(variable != []):
                elemento = variable[0].strip()
	        lista_variables.append(elemento)
    return lista_variables

#obtenemos clusters con grupos de variables que a nivel sintactico forman parte de otras y
#habra que separar
def obtener_vectores_variables_relacionadas(lista_variables_vectoriales):
    lista_control = [] # se mantiene un control de las que ya se han ido anadiendo
    lista_vectores_variables_relacionadas = []
    for indice in range(len(lista_variables_vectoriales)):
        variable1 = lista_variables_vectoriales[indice]#obtenemos la variable a comparar
        indice_actual = indice+1
        lista_parcial = []
        if (variable1 not in lista_control):
            for indice2 in range(indice_actual,len(lista_variables_vectoriales)):
                variable2 = lista_variables_vectoriales[indice2]
                if (variable2 not in lista_control):
                    if (variable2.find(variable1) == 0) and (variable2.index(variable1) == 0): #estan relacionadas
                        if(variable1 not in lista_parcial):
                            lista_parcial.append(variable1)
                        if(variable1 not in lista_control):
                            lista_control.append(variable1)
                        if(variable2 not in lista_parcial):
                            lista_parcial.append(variable2)
                        if(variable2 not in lista_control):
                            lista_control.append(variable2)
        if(lista_parcial != []):
            lista_vectores_variables_relacionadas.append(lista_parcial)
    return lista_vectores_variables_relacionadas

#funcion que devuelve vectores de variables que se relacionan por su nomenclatura
def obtener_apellidos_variables_listas(lista_variables_vectoriales,lista_vectores_variables_relaciondas,lista_variables_csv,lista_variables_eliminadas,separador_apellidos):
    diccionario_variables_apellidos = {}
    lista_variables_relacionadas = []
    for elemento in lista_vectores_variables_relaciondas:
        lista_variables_relacionadas+= elemento
    for variable_vectorial in lista_variables_vectoriales:
        if (variable_vectorial not in lista_variables_relacionadas): # las que dan problemas porque tomaran mas apellidos de los correspondientes, se tratan despues
            for variable_csv in lista_variables_csv:
                if (variable_csv.find(variable_vectorial) == 0) and (variable_csv.index(variable_vectorial) == 0): # comprobamos que la contiene y forma parte del nombre de la variable del csv
                    apellido = variable_csv.replace(variable_vectorial+separador_apellidos,'')
                    if(apellido == ''): # es decir, es una variable sin apellido pero no es individual
                        if (variable_vectorial) not in lista_variables_eliminadas:
                            apellido = variable_vectorial
                    if(variable_vectorial not in diccionario_variables_apellidos): #insertamos el primer apellido
                        if (variable_vectorial +separador_apellidos+ apellido) not in lista_variables_eliminadas:
                            diccionario_variables_apellidos[variable_vectorial] = [apellido]
                    else: #insertamos el n-esimo apellido
                        if (variable_vectorial +separador_apellidos+ apellido) not in lista_variables_eliminadas:
                            valores = diccionario_variables_apellidos[variable_vectorial]
                            valores.append(apellido)
                            diccionario_variables_apellidos[variable_vectorial] = valores
            #ordenamos la lista de valores
            if (variable_vectorial) in diccionario_variables_apellidos:
                valores = diccionario_variables_apellidos[variable_vectorial]
                valores = sorted (valores)
                diccionario_variables_apellidos[variable_vectorial] = valores
    #ahora creamos las lista de apellidos para las variables realacionadas
    lista_variables_apellidos = []
    for vector_variables in lista_vectores_variables_relaciondas:
        vector_variables_apellidos = []
        for variable_vectorial in vector_variables:
            lista_apellidos = []
            for variable_csv in lista_variables_csv:
                if (variable_csv.find(variable_vectorial) == 0) and (variable_csv.index(variable_vectorial) == 0): # comprobamos que la contiene y forma parte del nombre de la variable del csv
                    apellido = variable_csv.replace(variable_vectorial+separador_apellidos,'')
                    if(apellido == ''): # es decir, es una variable sin apellido pero no es individual
                        if (variable_vectorial) not in lista_variables_eliminadas:
                            apellido = variable_vectorial
                            lista_apellidos.append(apellido)
                    elif (variable_vectorial +separador_apellidos+ apellido) not in lista_variables_eliminadas:
                        lista_apellidos.append(apellido)
            if(lista_apellidos != []):
                vector_variables_apellidos.append([variable_vectorial,lista_apellidos])
        if(vector_variables_apellidos != []):
            lista_variables_apellidos.append(vector_variables_apellidos)
    #en este punto tenemos las listas de nombres relacionados entre si con los apellidos
    #[[[nombre,[apellido1,apellido2,apellidoN]],[nombre segundo,[apellido2,apellido3]]]
    #el siguiente paso es eliminar aquellos apellidos de las variables realcionadas que no les corresponden
    lista_listas_relacionadas = []
    diccionario_elementos_relacionados = {}
    for indice in range(len(lista_variables_apellidos)):
        lista_vectores_concatenacion_nombres_apellidos = []
        for indice_vector_relacionado in range(len(lista_variables_apellidos[indice])): #recorremos los nombres relacionados
            nombre_lista_apellidos = lista_variables_apellidos[indice][indice_vector_relacionado]
            nombre = nombre_lista_apellidos[0]
            diccionario_elementos_relacionados[nombre] = []
            vector_concatenaciones = [nombre]
            nombre = nombre_lista_apellidos[0] + separador_apellidos
            for apellido in nombre_lista_apellidos[1]:
                vector_concatenaciones.append(nombre + apellido)
            lista_vectores_concatenacion_nombres_apellidos.append(vector_concatenaciones)
        lista_listas_relacionadas.append(lista_vectores_concatenacion_nombres_apellidos)
    #tenemos la lista con las listas de vectores relacionados
    for lista_vectores_relacionados in lista_listas_relacionadas:
        for indice in range(len(lista_vectores_relacionados)):
            nombre = lista_vectores_relacionados[indice][0]
            indice_siguiente_lista = indice+1
            for indice_elemento_primero in range(1,len(lista_vectores_relacionados[indice])):
                variable1 = lista_vectores_relacionados[indice][indice_elemento_primero]
                encontrado = False
                for indice2 in range(indice_siguiente_lista,len(lista_vectores_relacionados)):
                    indice_elemento_segundo = 1 #empezamos en el segundo porque el primero marca que nombre es
                    while(encontrado == False) and (indice_elemento_segundo <= len(lista_vectores_relacionados[indice2])-1):
                        variable2 = lista_vectores_relacionados[indice2][indice_elemento_segundo]
                        if variable1 == variable2:
                            encontrado = True
                        indice_elemento_segundo+=1
                if(encontrado == False): #si al final de las comparaciones no se ha encontrado
                    #comprobamos conta la lista de variables_vectoriales
                    if(variable1 not in lista_variables_vectoriales):
                        variable1 = variable1.replace(nombre+separador_apellidos,"")
                        if nombre not in diccionario_elementos_relacionados:
                            diccionario_elementos_relacionados[nombre] = [variable1]
                        else:
                            valor = diccionario_elementos_relacionados[nombre]
                            valor.append(variable1)
                            diccionario_elementos_relacionados[nombre] = valor
    #combinamos los dos diccionarios
    for key in diccionario_elementos_relacionados:
        diccionario_variables_apellidos[key] = diccionario_elementos_relacionados[key]
    for key in diccionario_variables_apellidos:
        diccionario_variables_apellidos[key] = sorted(diccionario_variables_apellidos[key])
    return diccionario_variables_apellidos

def obtener_apellidos_variables_fichero(lista_variables_csv,lista_variables_eliminadas,separador_apellidos):
    diccionario_variables_apellidos = {}
    lista_variables_individuales = []
    for variable_csv in lista_variables_csv:
        variable_csv = variable_csv.split(separador_apellidos)
        apellido = ""
        variable = variable_csv[0]
        #determinamos si es individual o nombre con apellidos
        if(len(variable_csv) > 1): #tiene un apellido por lo menos
            for indice in range(1,len(variable_csv)):
                if(indice < len(variable_csv) -1 ):
                    apellido += variable_csv[indice]+ ' '
                else:
                    apellido += variable_csv[indice]
            if(variable not in diccionario_variables_apellidos):
                diccionario_variables_apellidos[variable] = [apellido]
            else:
                valores = diccionario_variables_apellidos[variable]
                valores.append(apellido)
                diccionario_variables_apellidos[variable] = valores
        else:
            lista_variables_individuales.append(variable)

    for key in diccionario_variables_apellidos:
        diccionario_variables_apellidos[key] = sorted(diccionario_variables_apellidos[key])
    return [lista_variables_individuales,diccionario_variables_apellidos]

#------mapper_reducer generar_listas_variables-------------------------------------------------------------------------------------

#------mapper_reducer matriz_adyacencia
#funcion que permite construir un diccionario con los nombres,nombres con apellido y apellidos a partir de la lectura del fichero que recibe como parametro
#el fichero esta compartido por el diccionario y las variables_csv por lo que habra que leer una u otra cosa segun lo que vayamos a construir
def generar_diccionario_fichero(identificador_fichero_diccionario):
    diccionario = {}
    with open(identificador_fichero_diccionario, 'r') as archivo_csv:
        lector_archivo = csv.reader(archivo_csv,delimiter="\t")
        for linea in lector_archivo:
            if(linea != []):
                if(linea [1] != '[]'):
                    linea[1] = linea[1][1:len(linea[1])-1]
                    linea[1] = linea[1].split(",")
                    values = []
                    for elemento in linea[1]:
                        elemento = str(elemento).replace('\'','').strip()
                        values.append(elemento)
                else:
                    values = []
                diccionario[linea[0]] = values
    return diccionario

def obtener_lista_variables_vectoriales_fichero(ruta_fichero):
    lista_vectoriales = []
    with open(ruta_fichero, 'r') as archivo_csv:
        lector_archivo = csv.reader(archivo_csv,delimiter="\n")
        for linea in lector_archivo:
	    linea = linea[0].split("\t")
	    lista_vectoriales.append(linea[0])
    return lista_vectoriales
#funcion que devuelve una matriz con las tres listas: nombres, nombres con apellidos y apellidos.
def obtener_listas_variables(ruta_fichero_variables_individuales,ruta_fichero_variables_vectoriales,ruta_fichero_apellidos):
    separador = "\n"
    lista_nombres = obtener_lista_variables_fichero(ruta_fichero_variables_individuales,separador)
    lista_apellidos = obtener_lista_variables_fichero(ruta_fichero_apellidos,separador)
    lista_nombres_con_apellidos= obtener_lista_variables_vectoriales_fichero(ruta_fichero_variables_vectoriales)
    variables_matriz_adyacencia = [lista_nombres,lista_nombres_con_apellidos,lista_apellidos]
    return variables_matriz_adyacencia

#funcion que devuelve una matriz con los rangos (filas) que arbarcanlas tres listas: nombres, nombres con apellidos y apellidos para poder calcular la matriz de adyacencia
def obtener_rangos_variables(lista_nombres,lista_nombres_apellidos,lista_apellidos):
    rango_nombres = []
    for indice in range(0,len(lista_nombres)):
        rango_nombres.append(indice)

    rango_nom_ape = []
    for indice in range(len(lista_nombres),len(lista_nombres) + len(lista_nombres_apellidos)):
        rango_nom_ape.append(indice)

    rango_ape = []
    for indice in range(len(lista_nombres_apellidos)+len(lista_nombres),len(lista_nombres) + len(lista_nombres_apellidos) + len(lista_apellidos)):
        rango_ape.append(indice)
    return [rango_nombres,rango_nom_ape,rango_ape]

def formatear_apellidos(cadena_apellidos):
    apellidos = cadena_apellidos.split(",")
    lista_apellidos = []
    for indice in range(len(apellidos)):
        formateado = apellidos[indice].replace('"','').replace(']','').replace('[','').replace('\'','')
	if(formateado[0] == ' '):
	    formateado = formateado[1:len(formateado)]
        lista_apellidos.append(formateado)
    return lista_apellidos

#funcion que permite generar la matriz asociada entre todos los mappers, dado que permite procesar en paralelo las filas de la misma
def generar_matriz_asociada(posicion,elemento,rangos,variables_matriz_adyacencia,separador_apellidos):
    matriz_parcial_asociada = [] # matriz en la que aparece el nombre/nombre con apellidos (si en la de adyacencia hay un 1) o 0s

    #---------------generacion de "submatriz nombres sin apellidos"----------------------------
    #primeras filas de la matriz de adyacencia, de la fila 0 a la numero total_nombres -1
    if(posicion in rangos[0]):
        for indice in range(len(variables_matriz_adyacencia)):
            if(indice in rangos[0] and elemento[0] == variables_matriz_adyacencia[indice]):
                matriz_parcial_asociada.append(elemento[0])
            else:
                matriz_parcial_asociada.append(0)

  #---------------generacion de "submatriz nombres con apellidos----------------------------

    if(rangos[2] != []):
        inicio_matriz_C = rangos[2][0] # primer nombre_apellido en la lista de variables

    if(posicion in rangos[1]):
        for indice in range(len(variables_matriz_adyacencia)):
            if(indice>=inicio_matriz_C):
                if (variables_matriz_adyacencia[indice] in elemento[1]):
		    if(elemento[0] == variables_matriz_adyacencia[indice]):
		        variable = elemento[0]
                    else:
                        variable = elemento[0]+separador_apellidos+ variables_matriz_adyacencia[indice]
                    matriz_parcial_asociada.append(variable)
                else:
                    matriz_parcial_asociada.append(0)
            else:
                matriz_parcial_asociada.append(0)

    #---------------generacion de "submatriz apellidos ----------------------------
    if(posicion in rangos[2]):
        for indice in range(len(variables_matriz_adyacencia)):
            matriz_parcial_asociada.append(0)

    print posicion,"\t",matriz_parcial_asociada

#------mapper_reducer matriz_adyacencia---------------------------------------------------------------------------------------------

#------mapper_reducer matriz_pesos---------------------------------------------------------------------------------------------
#funcion que permite generar un diccionario siendo la clave el numero de columna y el valor la variable que ocupa esa columna
def generar_diccionario_variables_indices_csv(lista_variables):
    diccionario_variables = {}
    for indice in range(len(lista_variables)):
        diccionario_variables[indice] = lista_variables[indice]
    return diccionario_variables

#funcion que crea la matriz de adyacencia y la asociada(nombres, nombres con apellidos)
#recibe como parametro un diccionario en el que se recogen todos los nombres, apellidos y nombres con apellidos
def generar_matriz_adyacencia_y_asociada(archivo_contenedor_matriz_asociada):
    matriz_adyacencia = []
    matriz_asociada = []
    with open(archivo_contenedor_matriz_asociada, 'r') as archivo_csv:
        lector_archivo = csv.reader(archivo_csv,delimiter="\t")
        for fila in lector_archivo:
            fila_matriz_asociada = []
            fila_matriz_adyacencia = []
            for elemento in fila[1].split(","):
                elemento = elemento.replace(']','').replace('[','').replace('\'','').strip()
                if(elemento.isdigit()):
                    elemento = int(elemento)
                fila_matriz_asociada.append(elemento)
                if(elemento != 0):
                    fila_matriz_adyacencia.append(1)
                else:
                    fila_matriz_adyacencia.append(0)
            matriz_asociada.append(fila_matriz_asociada)
            matriz_adyacencia.append(fila_matriz_adyacencia)
    return [matriz_adyacencia,matriz_asociada]

#diccionario que permite una busqueda mas rapida de los elementos que exiten en la matriz de adyacencia
def generar_diccionario_relacion_madyacencia_masociada(matriz_asociada):
    diccionario_matriz_asociada = {}
    for fila in range(len(matriz_asociada)):
        for columna in range(len(matriz_asociada[fila])):
            elemento = matriz_asociada[fila][columna]
            if(elemento != 0):
                diccionario_matriz_asociada[elemento] = [fila,columna]
    return diccionario_matriz_asociada

def copiar_matriz_por_valor(matriz_original):
    copia = []
    for fila in matriz_original:
        copia.append(list(fila))
    return copia

#comprueba si el elemento leido es un numero o no
def check_number(number):
    try:
        float(number)
        return True
    except ValueError:
        return False

def generar_matriz_pesos(registro_actual,variables_elim,dic_var_fich,mat_adya,dic_var_pos_matriz_ad):
    matriz_pesos = []
    matriz_pesos = copiar_matriz_por_valor(mat_adya) # matriz de pesos de la fila n
    for indice in range(len(registro_actual)):
        if(dic_var_fich[indice] not in variables_elim):            
            variable = dic_var_fich[indice]
            posicion = dic_var_pos_matriz_ad[variable] # [fila,,columna]       
            elemento = registro_actual[indice]#.replace('"','')
            es_numero = check_number(elemento)
            elemento_sin_espacios = elemento.strip()
            if(es_numero == True):
                if(math.isnan(float(elemento))):
                    elemento = "'nan'"
                else:
                    elemento = float(elemento)
	    else:
                elemento_sin_espacios = elemento.strip()
                if(elemento_sin_espacios == '' or elemento_sin_espacios == ""):
                    elemento = "'nan'"
            matriz_pesos[posicion[0]][posicion[1]] = elemento
    return matriz_pesos

def crear_diccionario_variables_modificadas(variables_modificadas):
    diccionario_variables_mod = {}
    for indice in range(len(variables_modificadas)):
        tupla_variables = variables_modificadas[indice]
        diccionario_variables_mod[tupla_variables[1]] = tupla_variables[0]
    return diccionario_variables_mod

#funcion que formatea las cadenas de la entrada estandar a lista de valores del diccionario
def formatear_cadena_valor_diccionario(value):    
    if value == '[]':
        value = list()
    else:
        values_mod = []
        value = value[1:len(value)-1]
        value = value.split(",")
        for elemento in value:
            elemento = str(elemento).replace('\'','')
	    if(elemento[0] == ' '):
	    	elemento = elemento[1:len(elemento)] # quitar el espacio del principio
            values_mod.append(elemento)
        value = values_mod
    return value


